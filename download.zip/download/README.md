#Kittens

##installation

1. Extract ```download```
2. go to ```chrome://extensions```
3. Drag extracted ```download``` folder to page
4. Enjoy!